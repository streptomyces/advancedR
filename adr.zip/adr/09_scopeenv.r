##############################
### Scope and Environments ###
##############################

# Scope of a variable is where, in a running program, it is
# accessible.

x <- 42;

# Functions and environments define the scope of variables
# in them. In an R session the default environment is the global
# environment named .GlobalEnv

# Lexical scope: Functions are evaluated in the environment
# in which they are defined.
#
# Closures
#
# The environment provides values for any unbound symbols in
# in the body of a function when the function is evaluated.

rm(list = ls());

rate <- 0.2;
withvat <- function(exvat) {
  return(exvat + (exvat * rate))
}


vatfuncgen <- function(vatrate) {
  vatfun <- function(exvat) {
    return(exvat + (exvat * vatrate))
  }
  return(vatfun)
}

standard <- vatfuncgen(0.2);
reduced <- vatfuncgen(0.1);

standard(100)
reduced(100)

environment(withvat);
environment(standard);
environment(reduced);

ls(envir = environment(standard));
ls(envir = environment(reduced));
ls(envir = .GlobalEnv);

parent.env(environment(standard));

superlow <- standard;
sl.env <- new.env();
sl.env$vatrate <- 0.05;
environment(superlow) <- sl.env;

superlow(100);
parent.env(environment(superlow));
parent.env(parent.env(environment(superlow)));
parent.env(parent.env(parent.env(environment(superlow))));

### assign() and get() ###

# Standard VAT goes up to 0.25.

assign("vatrate", 0.25, envir = environment(standard));

standard(100);

get("vatrate", envir = environment(superlow));

# The effective environment is almost always a nesting of
# environments.

#################################
### The search path. search() ###
#################################

search();

attach(environment(standard));

search();

ls(); # Notice that there is no vatfun in the listing.

vatfun(100); # But you can still call vatfun.


