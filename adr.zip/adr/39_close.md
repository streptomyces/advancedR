* R is not the most convenient environment for all kinds
  of data processing.

* Some things might be easier to do in a general purpose
  programming language such as Perl or Python.

* You can find plenty of help and support for Python and
  Perl around the NRP.

* Ability to read documentation quickly is more important
  than you think. Not just in R.

* R manuals webpage.
  https://cran.r-project.org/manuals.html

* PDF of the Introduction to R book.
  https://cran.r-project.org/doc/manuals/r-release/R-intro.pdf

* Tidyverse (dplyr, tibbles, ggplot and more) documentation.
  https://www.tidyverse.org/

* RNA-Seq data analysis using edgeR.
  https://f1000research.com/articles/5-1438

