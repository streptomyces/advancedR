##################
### Histograms ###
##################

# The data in septaldist.csv contains the inter-septal
# distances measured in the wild type and a mutant
# strain of Streptomyces. The first column contains the
# distances in μm and the second column contains either
# "wt" or "mut" (factor).

rm(list = ls());

df <- read.csv("data/septaldist.csv");
head(df)
tail(df)
wt <- df[df$strain == "wt", 1]
mut <- df[df$strain == "mut", 1]

# We have the two vectors made above and we wish to plot
# their histograms next to each other so that we can see
# the overlap between them. hist() has an argument named
# add which adds to an existing histogram rather than
# plot a new one. So we decide to use this.

hist(wt, breaks = 20, col = "#00009955",
     main = "Histograms of WT and Mutant");

# Notice the add argument below.
hist(mut, breaks = 20, col = "#00990055", add = TRUE);


# Most of the histogram for the mutant is beyond the
# limit of the x axis. So we decide to extend the limits
# of the x-axis.

hist(wt, breaks = 20, col = "#00009955",
     xlim = c( min(c(wt,mut)), max(c(wt,mut)) ),
     main = "Histograms of WT and Mutant");
hist(mut, breaks = 30, col = "#00990055", add = TRUE);

# Now we are losing the tops of the central bars of the
# mutant histogram. So we need to extend the y-axis as
# well. The problem is that the y-axis range gets
# decided in the call to hist(). It cannot be determined
# by the looking at data.

# We need to find out the height of the tallest bar in
# the histogram and adjust the upper limit of the y-axis
# before the histogram is actually drawn. For this we
# need to save the return values of the calls to hist()
# and also suppress actual plotting when hist() is
# called.

hwt <- hist(wt, breaks = 20, plot = FALSE);
hmut <- hist(mut, breaks = 30, plot = FALSE);

# Examine hwt and hmut here.

xlm <- c( min(c(wt,mut)), max(c(wt,mut)) );
ylm <- c( min(c(hwt$counts, hmut$counts)), max(c(hwt$counts, hmut$counts)) );

plot(hwt, col = "#00009955",
     xlim = xlm, ylim = ylm, xlab = "Septal distance",
     main = "Histograms of WT and Mutant"
);

plot(hmut, col = "#00990055", add = TRUE);

### Putting the final plot in a png file.

png(filename = "../intersept.png", width = 1200, height = 800);
plot(hwt, col = "#00009955",
     xlim = xlm, ylim = ylm, xlab = "Septal distance",
     main = "Histograms of WT and Mutant"
);

plot(hmut, col = "#00990055", add = TRUE);
dev.off()

# There are similar functions for jpeg, tiff, pdf,
# postscript (ps) etc.
#
# Journals often want Encapsulated Postscript (eps) files.
# setEPS() calls ps.options() with reasonable defaults.
# Then you can call postscript() just like you called
# png() above to get an eps file of your plot.


### Using ggplot2 ###

ggplot(df, aes(sep.dist, fill = strain)) +
  geom_histogram(alpha = 0.3, bins = 60, colour = "grey80")

ggplot(df, aes(sep.dist, fill = strain)) +
  geom_histogram(alpha = 1, bins = 40, colour = "grey80") +
  facet_wrap(~strain)



h1 <- ggplot(df, aes(sep.dist, fill = strain)) +
  geom_histogram(alpha = 0.3, bins = 60, color = "grey70")
h1


# Main title
mt <- "Histogram of interseptal distances in mutant"
mt <- paste(mt, "and wild type strains");

# Axis labels
h1 <- h1 + labs(x = "Interseptal Distance", y = "Count",
                title = mt);
h1

h2 <- ggplot(df, aes(strain, sep.dist, colour = strain)) +
  geom_boxplot()

h3 <- ggplot(df, aes(strain, sep.dist, colour = strain)) +
  geom_violin()


# Writing ggplot2 objects to a file.

pdffn <- c("../hist123.pdf");
pdf(pdffn)
print(h1)
print(h2)
print(h3)
dev.off()

# ggsave()

pdffn <- c("../hist1.pdf");
ggsave(pdffn, h1) # One plot only.


