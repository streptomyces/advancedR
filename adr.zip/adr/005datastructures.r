#######################
### Data structures ###
#######################

# Collections of the basic data types.

# Several data structures are provided in R as classes.

# It is possible to make your own but we will not be doing
# so. The ones provided are sufficient for what we do.

# They range in complexity and flexibility.

# Use the simplest data structure that will do the job.

###############
### Classes ###
###############

# Data structures with associated functions (methods).

# e.g. the class data.frame has the following methods.

# [             [[            [[<-          [<-           $<-          
# aggregate     anyDuplicated as.data.frame as.list       as.matrix    
# by            cbind         coerce        dim           dimnames     
# dimnames<-    droplevels    duplicated    edit          format       
# formula       head          initialize    is.na         Math         
# merge         na.exclude    na.omit       Ops           plot         
# print         prompt        rbind         row.names     row.names<-  
# rowsum        show          slotsFromS3   split         split<-      
# stack         str           subset        summary       Summary      
# t             tail          transform     type.convert  unique       
# unstack       within 

# A class is a recipe for making objects and a "constructor"
# method is usually available.

###############
### Objects ###
###############

# Objects are "instances" of classes.

# Objects of a class have all the methods of the class
# available to them.

# Objects can be of more than one class. Then they have
# methods of all the classes available to them.

# There are no simple variables in R.

# Even if you need to store just one value you use a data
# structure that is capable of storing multiple values.


