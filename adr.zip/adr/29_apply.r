######################
### apply() et al. ###
######################

### apply() ###

rm(list = ls());

# Make a matrix

set.seed(20230201); # So that we have the same random numbers.
x <- runif(60, min = 20, max = 30)
dim(x) <- c(15, 4);
x

d <- as.data.frame(x);
d


# Define a function to be applied later.

apfun <- function(arg1) {
return(arg1 - mean(arg1));
}

# Apply the function to each row of x

apply(x, 1, apfun);
apply(d, 1, apfun);

# Each application results in a column in the returned matrix.
# Hence the transpose below.

t(apply(x, 1, apfun));
t(apply(d, 1, apfun));

# Apply the function to each column of x

apply(x, 2, apfun);
apply(d, 2, apfun);

# You still get one column per application.

# If each application returns a single value then

# The option simplify is TRUE by default.

apply(x, 2, FUN = apfun, simplify = T);

# Below gives a list with one element for each application
# of FUN
apply(x, 2, FUN = apfun, simplify = F);


### lapply() and sapply() ###
# Apply a function over a List or a Vector.
# sapply() tries to simplify the return value to a vector or
# matrix.

lapply(x, apfun) # Matrices are vectors with dimensions!
sapply(x, apfun) # Matrices are vectors with dimensions!

# Data frames are lists of columns.
lapply(d, apfun)
sapply(d, apfun) # Same as apply(d, 2, apfun);

lapply(d, mean)
sapply(d, mean)

### tapply() ###

# We saw this when doing Factors.

hwt <- read_csv("data/hw.csv");

tapply(hwt$hw, hwt$strain, mean);
tapply(hwt$hw, hwt$strain, sd);
tapply(hwt$hw, hwt[, c("strain", "microscope")], sd);

### aggregate() ###

aggregate(hwt$hw, by = list(hwt$microscope, hwt$strain),
FUN = mean);

# There are NAs in the microscope column.
print(hwt[49:60,], n = 30)

x <- hwt$microscope
x[is.na(x)] <- "U";
hwt <- hwt %>% mutate(microscope = x)
print(hwt[49:60,], n = 30)

aggregate(hwt$hw, by = list(hwt$microscope, hwt$strain),
FUN = mean);

