######################
### apply() et al. ###
######################

### apply() ###

rm(list = ls());

# Make a matrix

x <- runif(60, min = 20, max = 30)
dim(x) <- c(15, 4);
x

# Define a function to be applied later.

apfun <- function(arg1) {
return(arg1 - mean(arg1));
}

# Apply the function to each row of x

apply(x, 1, apfun);

# Each application results in a column in the returned matrix.
# Hence the transpose below.

t(apply(x, 1, apfun));

y <- cbind(x, t(apply(x, 1, apfun)));
y


### lapply() ###

# Apply a function over a list or a vector.
# Returned list is as long as the argument.

# Single column data frame.
strepgenes <- read.csv("data/strepGenes.txt", header = F,
                       stringsAsFactors = F);

# Function to apply
canoname <- function(x) {
spl <- strsplit(x, "\\s+", perl = TRUE);
cano <- spl[[1]][!grepl("SVEN_|SVEN15_|vnz_|^-$",
                        spl[[1]], perl = TRUE)];
return(cano);
}

lapply(strepgenes[[1]], canoname); # a list

unlist(lapply(strepgenes[[1]], canoname)); # a vector.


### sapply() ###

# Will try to simplify the return value to a vector.

sapply(strepgenes[[1]], canoname); # named vector

unname(sapply(strepgenes[[1]], canoname));

temp <- cbind(strepgenes,
cano = unname(sapply(strepgenes[[1]], canoname)));

### tapply() ###

# We saw this when doing Factors.

hwt <- read_csv("data/hw.csv");

tapply(hwt$hw, hwt$strain, mean);
tapply(hwt$hw, hwt$strain, sd);

### aggregate() ###

aggregate(hwt$hw, by = list(hwt$microscope, hwt$strain),
FUN = mean);

# There are NAs in the microscope column.
print(hwt[49:60,], n = 30)

x <- hwt$microscope

x[is.na(x)] <- "U";

hwt <- hwt %>% mutate(microscope = x)
print(hwt[49:60,], n = 30)

aggregate(hwt$hw, by = list(hwt$microscope, hwt$strain),
FUN = mean);

