###############
### RNA-Seq ###
###############

# Use of the package edgeR to analyse RNASeq data

# edgeR is a Bioconductor package you can read about it
# here
# https://www.bioconductor.org/packages/release/bioc/html/edgeR.html
# Start with the User Guide. You may have to read the
# Reference Manual to do somethings.

# Using these two it is possible to develop a sequence
# of R commands which will do the analysis you desire on
# the data you have. This is a general pattern in
# Bioconductor packages.

### The experiment ###

# Hfq is a small RNA binding protein originally
# identified as the host factor essential for the
# replication of the bacteriophage Qβ. Two biological
# replicates each of the wild type and a Hfq deletion
# mutant of a Pseudomonas strain STR25 were subjected to
# RNA-Seq analysis.

# Reads from the sequencer (in fastq files) were aligned
# to the Pseudomonas genomic sequence using bowtie2 to
# get SAM files.

# bowtie2 --phred33 -x bwt2ndx/STR25 \
# -I 100 -X 400 -p 12 --no-unal \
# -1 rs1-R1.fastq -2 rs1-R2.fastq -S sam/rs1.sam \
# 2> "bowtie2Reports/rs1.bwt2repo"
 
# Then samtools was used to convert these SAM files to BAM files.
 
# samtools view -b -o bam/rs1.bam --threads 8 sam/rs1.sam
 
# Then, in R, the function featureCounts() of the
# Rsubread package was used to get the counts of reads
# overlapping each of the 6003 genes. These counts have
# been saved in the files
 
# featureCounts/rs1
# featureCounts/rs2
# featureCounts/rs3
# featureCounts/rs4

# It is also possible to do the above using samtools
# functions bedcov and depth. Another possibility is to
# use tools in the Rsubread package to carry out the
# alignment as well as feature counting. Anyhow, we have
# to arrive at counts of reads covering each gene.
 
# This is where we will pick up this analysis now and
# take it to completion ending in a table of log fold
# changes for all the genes in the genome. We will use
# functions provided in BioConductor package edgeR for
# doing this.
 
### Analysis in R ###

rm(list = ls());
library("edgeR");

fcpath = "data/featureCounts";
list.files(path = fcpath);
files <- list.files(path = fcpath);
files


# use of rep() to make groups.
temp <- c("wt", "hfq");
groups <- rep(temp, each = 2);

fg <- data.frame(files = files, group = groups);
fg;

# Both columns of fg are factors. So we can call levels() on them.
levels(fg$files);
levels(fg$group);

# labels for each sample.
lbs <- paste0(groups, c("A", "B"));
lbs
# Examine the values of fg and lbs at this stage
# to make sure they are as you want them to be.

# Now we are ready to read the data from the files into R.

d <- readDGE(fg, path = fcpath, labels = lbs, header = FALSE);

### Examine d here. What class does d belong to? ###
d
class(d)
names(d);

# Saving individual objects
saveRDS(d, file = "after_readDGE.rds");
# d <- readRDS("after_readDGE.rds");

# Saving a list of objects.
save(files, groups, fg, lbs, d, file = "after_readDGE")
# load("after_readDGE");

# Saving entire workspace.
save.image(file = "after_readDGE.image")
# load("after_readDGE.image");
# In a new session of R, you will need to load the
# required libraries again.

### Add gene length information.

gene.lens <- read.csv(file = "data/str25.genelengths",
                      stringsAsFactors = F);

d$genes <- gene.lens;

all.equal(rownames(d$counts), d$genes$gene)


### Normalisation factors.

d <- calcNormFactors(d);

# Drawing of the design matrix
#            wt        hfq
# wtA         1         0
# wtB         1         0
# hfqA        0         1
# hfqB        0         1

# Make the design matrix. Alternative 1.
dm = matrix(c(1,1,0,0,0,0,1,1), nrow = 4);
rownames(dm) = c("wtA", "wtB", "hfqA", "hfqB");
colnames(dm) = c("wt", "hfq");
dm

# Make the design matrix. Alternative 2.
des <- model.matrix(~0+fg$group)
des
rownames(des) <- lbs;
colnames(des) <- levels(fg$group);
des


names(d);
d <- estimateDisp(d, design = des);
names(d)


#################################
### Do the following yourself ###
#################################

# 1. Examine the output of methods(class = class(d))

# 2. Amongst a lot of other things, the above will show
# you a method named rpkm().

# 3. Have a look at the help for rpkm().

# 4. Now use rpkm() to get the RPKMs and store them in
# wt.hfq.rpkm.

# 5.  Examine the top of wt.hfq.rpkm using head().

# 6. write.csv(wt.hfq.rpkm, file =
# "../wt_hfq_RPKM.csv")


###############################
### Differential Expression ###
###############################

# The object d made above has all the data required to
# determine which genes are differentially expressed
# between the WT and Hfq, to what extent and in which
# direction.

# Use of exactTest() and topTags()

et <- exactTest(d, pair = c("wt", "hfq"));

byFC <- topTags(et, sort.by = "logFC");
byFC;

unsorted_lfc <- topTags(et, sort.by = "none", n = nrow(d));
saveRDS(unsorted_lfc$table, "unsorted_lfc.rds")

byPV <- topTags(et, n = nrow(d), sort.by = "PValue");
write.csv(byPV, file = "../wt_hfq_DE.csv", row.names = F);

# head(byPV); # Fails.

class(byPV);
names(byPV);

class(byPV$table);

head(byPV$table);

de.table <- byPV$table

# Hfq is SS_0520 and it has been deleted in the strain
# we are referring to as hfq. So it should be
# significantly down-regulated.

de.table["SS_0520",];


# Collecting the RPKMs of the most highly changed genes
 
# "wt.hfq.rpkm" is a matrix. "de.table" is a data frame.
# "de.table" is ordered such that the most significantly
# changed genes are at the top.
 
# How will you get the RPKMs of the 30 most
# significantly changed genes?
 
#################################
### Do the following yourself ###
#################################

# 1. From de.table get a vector v, of the first 30 row
# names.

# 2. Create top30.rpkm by subscripting wt.hfq.rpkm to
# get the rows in vector v made above and all columns.

#####################################
### Why use log2 for fold change? ###
#####################################

# Linear scale is asymmetric.

# Two fold up-regulation is 2

# Two fold down-regulation is 0.5

# So the entire down-regulation side is squeezed between
# 0 and 1.

plot(de.table$logFC, pch = 20)
plot(2**(de.table$logFC), pch = 20)

lfc <- sample(de.table$logFC, length(de.table$logFC));
plot(lfc, pch = 20)
plot(2**(lfc), pch = 20)

# Table of linear to log2 values.
x <- c(seq(2,16), seq(20, 200, by = 20), 500, 1000);
lx <- log2(x);
lin2log <- data.frame(x = x, log2.x = lx)
lin2log

# Table of log2 to linear values
log2lin <- data.frame(log2.x = seq(0, 10, by = 0.5),
                      x = 2**(seq(0,10, by = 0.5))
                      );
log2lin


# Keep the following in mind when working with logFC and
# linearFC.

# 1. You cannot take the log of a negative number.

# 2. Log of (positive) numbers less than 1 is negative.

# 3. Log of 1 is zero.

# 4. Log of zero is -Inf.

# 5. Raise the base to the logFC value to get the linear
# fold change.




