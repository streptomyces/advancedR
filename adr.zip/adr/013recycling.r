######################################
### Recycling in Vector operations ###
######################################


#################################
### Do the following yourself ###
#################################

# 1. Store the sequence from 1 to 5 in vector x.
# 2. Store the sequence from 21 to 25 in vector y.
# 3. Examine the result of y * x.

#############################################################
  
# 4. Store the sequence from 21 to 30 in vector z.
# 5. Confirm the lengths of x and z using the function length().
# 6. Examine the result of z * x.

#############################################################
  
# 7. Store the sequence from 1 to 7 in vector u.
# 8. Examine the result of z * u.



#############################################################
#############################################################
# In operations involving two vectors of unequal length, elements of the
# shorter vector get recycled.
# If the longer vector is not an integer multiple of the shorter vector
# you get a warning but the operation is valid and successful.



