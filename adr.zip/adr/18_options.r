###############
### Options ###
###############

# Default behaviour in R is controlled by some global
# options. stringsAsFactors is one of the options. To see
# the setting of an option we use the function getOption.

getOption("stringsAsFactors");
getOption("digits");

# To change or set options we use the function options().

options(stringsAsFactors = FALSE, digits = 7,
EBImage.display = "raster");

getOption("EBImage.display");

# Any option can be set; whether it has any effect or not
# depends on whether base R or any package read it or not.

options(thisMeansNothing = "really");
getOption("thisMeansNothing");


