######################################
### Querying the nature of objects ###
######################################

# Mode

# The mode of an object signifies the type of data in it.
# numeric, character, logical, complex and raw.

rm(list = ls());

x <- seq(1, 5, by = 0.5);
mode(x);
y <- as.integer(x);
mode(y);

# Type and Storage mode

# These two are approximately the same.
storage.mode(x);
typeof(x);

storage.mode(y);
typeof(y);

# Class

# The class of an object is the class that the object is an
# instance of. For vectors it is the same as the mode. list,
# data.frame, matrix, function. Class of an object determines what
# methods are available to apply on it and also how those methods
# behave.

class(x);
class(y);

# str() is useful to display the internal structure of R objects.
# Especially useful for data frames and more complex objects.

hx <- hist(rnorm(300), plot = F);
str(hx)

methods(class = class(hx));

methods(class = "data.frame");


