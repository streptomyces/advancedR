######################################
### Querying the nature of objects ###
######################################

# Mode

# The mode of an object signifies the type of data in it.
# numeric, character, logical, complex and raw.

rm(list = ls());

x <- seq(1, 5, by = 0.5);
mode(x);
y <- as.integer(x);
mode(y);

# Type and Storage mode

# These two are approximately the same.
storage.mode(x);
typeof(x);

storage.mode(y);
typeof(y);

# Class

# The class of an object is the class that the object is an
# instance of. For vectors it is the same as the mode. list,
# data.frame, matrix, function. Class of an object determines what
# methods are available to apply on it and also how those methods
# behave.

class(x);
class(y);

# str() is useful to display the internal structure of R objects.
# Especially useful for data frames and more complex objects.


#################################
### Do the following yourself ###
#################################

# When you plot a histogram all the results calculated for
# making the plot are returned to you as an object.

hx <- hist(rnorm(300, mean = 3, sd = 2));

# 1. What is the class of hx?

# 2. Thinking of hx as a named vector, display the names of
# the elements of hx.

# 3. One of the names you will see in 2. is counts. Can you
# display the counts?


