###############
### EBImage ###
###############

library("EBImage");

jpgfn <- c("data/hollyhock.jpg");
hhock <- readImage(jpgfn);



