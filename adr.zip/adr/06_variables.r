####################################
### Names, symbols and, bindings ###
####################################

# Names (or symbols) are handles or labels for objects
# through which we can access the objects.

# After an assignment like below.

x <- 42;

#     the name "x" has the value 42.

#     the value 42 has a label attached to it with "x"
#     written on the label.

#     The name "x" is bound to the value 42.

#     Explain unbound (non-existent) names.

# It is not accurate to imagine x to be a container
# containing the value 42.

# Nothing prevents two different names from refering to
# the same object. In fact this is what happens after

y <- x;

# What happens when rm is invoked?

rm(x);


