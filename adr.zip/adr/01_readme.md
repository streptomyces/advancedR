# Advanced R 30 Jan and 1 Feb 2023

# [https://bit.ly/3pPBwwC](https://bit.ly/3pPBwwC)

## Requirements

* A reasonably capable computer.
* Installation of R version 4. (4.1.2 is the most recent).
* Installation of a recent version of RStudio (2021.09.2-382 is
  the most recent).
* Administrative rights on your computer will be needed (at least
  on the first day) to be able to install some required add-on packages
  for R.

## Timings for both Mon 30 Jan and Wed 1 Feb 2023

---------------------        ---------------
Course                       0930  to   1100
Coffee break                 1100  to   1130
Course                       1130  to   1300
Lunch                        1300  to   1400
Course                       1400  to   1530
Coffee break                 1530  to   1600
Course                       1600  to   1730
---------------------        ---------------

## As soon as you arrive

* Login to a PC in the training theatre using your institute identity.

* Point your web browser to the url shown at the top
  which is [https://bit.ly/3pPBwwC](https://bit.ly/3pPBwwC)
  which is the same as 
  [https://streptomyces.github.io/advancedR/](https://streptomyces.github.io/advancedR/).

## How will this course work?

- I will talk about commands and syntax.
- You will run some commands along with me to see them
  in action.
- I will explain the commands and the syntax you have
  just seen in action.

### Sometimes there will be things for you to do on your own.

+ These tasks will be described in plain english.
+ You will have to think how to achieve them in R using
   as many steps as you need.
+ Finally, I will show you how I would have done the
  tasks but keep in mind that, if you got the right results,
  your way of doing them may also be correct.

## Limitations

* I use R on a daily basis but not RStudio.
* The focus of this course is on R syntax and
  techniques rather than statistics.
* The aim is to clarify the workings of R so that you
  can build your own data analysis solutions and workflows.

[Preparations](preparations.html)

[.](readme.html)

