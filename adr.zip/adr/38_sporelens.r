#####################
### Spore Lengths ###
#####################

# Spore lengths were measured in 5 mutants (L, S, T, U,
# V) and the WT of a species of Streptomyces grown in 2
# or 3 different growth media. Now we wish to know what
# effect do the mutations and the growth media have on
# spore lengths.

# In the directory named spores there are files named
# L1, L2, S1, S2, S3, T1, T2, U1, U2, U3, V1, V2, V3,
# WT1, WT2. The beginning letters of the filename
# represents the strain and the following digit
# represents the growth medium.
#
# All of these files contain just one column containing
# spore lengths.

# Please do the following with me.

list.files();
list.dirs();
list.files(path = "data/spores");
list.files(path = "data/spores", full.names = TRUE);
basename("data/spores/WT1");

alist <- list(); # An empty list;

# for loop below.
for(file in list.files(path = "data/spores", full.names = T)) {
  tf <- read.delim(file, col.names = c("spore.length"), header = F);
  id.lst <- basename(file);
  alist[[id.lst]] <- tf$spore.length;
}

names(alist);
head(alist$L1)

# Use of stack() to get data frame of spore lengths and a factor.
sldf <- stack(alist);
head(sldf);
# stack() used the column names "values" and "ind" by default.

# Change column names.
colnames(sldf) <- c("spore.len", "strain");
head(sldf);
class(sldf$strain);
levels(sldf$strain);

# At this time the "strain" column contains both the strain as
# well as the growth medium information. Below we separate the
# two into two different factors.

# Use of regular expressions below.
str <- sub("\\d+$", "", sldf$strain, perl = TRUE);
medium <- sub("^[A-Z]+", "M", sldf$strain, perl = TRUE);

sldf$strain <- factor(str);
sldf$medium <- factor(medium);
head(sldf);

# Now we have the data in a form that can be used in
# function calls. We are going to use this data for plotting
# but this form of data is also the form you need if you
# wish to do ANOVA.

# Run aov() and anova()
# medium.aov <- aov(spore.len ~ medium, data = sldf);
# anova(medium.aov);
#
# strain.aov <- aov(spore.len ~ strain, data = sldf);
# anova(strain.aov)


# Scatter plot spore.len against medium
ggplot(sldf, aes(x = medium, y = spore.len,
                 colour = medium)) +
  geom_point()

# Scatter plot log2(spore.len) against medium
ggplot(sldf, aes(x = medium, y = log2(spore.len),
                 colour = medium)) +
  geom_point()

# Scatter plot log2(spore.len) against strain
ggplot(sldf, aes(x = strain, y = log2(spore.len),
                 colour = strain)) +
  geom_point()

# Separate boxplots of spore.len against growth medium
# using facet_wrap().
ggplot(sldf, aes(x = medium, y = log2(spore.len),
                 colour = medium, fill = medium)) +
  geom_boxplot() + facet_wrap(~strain)


#################################
### Do the following yourself ###
#################################

# 1. Make a boxplot keeping the x axis as strain but
# changing colour and fill to medium. (Don't use
# facet_wrap()).

# 2. Make another boxplot keeping the x axis as medium
# and changing colour and fill to strain.

# 3. How can you keep both the above plots in view so
# that you can compare them?

# 4. Try geom_violin() instead of geom_boxplot().

#################################

crpfun <- colorRampPalette(
  c("red", "yellow", "brown", "violet", "blue", "green"),
    alpha = FALSE, space = "Lab");
crpfun(6)

ggplot(sldf, aes(x = medium, y = log2(spore.len),
                 colour = strain, fill = strain)) +
  geom_boxplot() +
  scale_colour_manual(values = (crpfun(6))) +
  scale_fill_manual(values = (crpfun(6)))


# Do we have enough data? Plotting counts.
# geom_bar() does the counting for us.

ggplot(sldf, aes(x = medium)) +
  geom_bar(colour = "darkblue", fill = "darkblue") +
  facet_wrap(~strain)

ggplot(sldf, aes(x = strain)) +
  geom_bar(colour = "brown", fill = "brown") +
  facet_wrap(~medium)

# geom_col() does not count. Use this if you have
# counts.

countvec <- integer();
for(s in levels(sldf$strain)) {
s.count <- nrow(subset(sldf, strain == s))
countvec[s] = s.count;
}
countvec

cdf <- data.frame(count = countvec, strain = names(countvec))
cdf

# Or
cdf <- stack(countvec);
colnames(cdf) <- c("count", "strain");
cdf


ggplot(cdf, aes(x = strain, y = count)) +
  geom_col()




