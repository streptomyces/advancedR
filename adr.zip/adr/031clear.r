################################
### Clearing your work space ###
################################

### Scenario 1 ###

x <- rnorm(20, mean = 20, sd = 3);
y <- rnorm(20, mean = 10, sd = 3);

# The above x and y are two objects sitting around from older work.

# Below you create x and y again for some new analysis.
# But the assignment to y fails because of a syntax error.

x <- rnorm(20, mean = 212, sd = 3);
y <- rnorm(20, mean = 210, , sd = 3);   # Assignment fails.

z <- x - y;  # This is being evaluated using the new x and the old y!

z;


### Scenario 2 ###

rm(list=ls());

x <- rnorm(20, mean = 212, sd = 3);
y <- rnorm(20, mean = 210, , sd = 3);  # Assignment fails.

z <- x - y; # Fails.
z;

# You make the correction needed and run again.

x <- rnorm(20, mean = 210, sd = 3);
y <- rnorm(20, mean = 212, sd = 3);

z <- x - y;

z;




