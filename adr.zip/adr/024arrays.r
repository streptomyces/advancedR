##############
### Arrays ###
##############

# Like matrices but can have more than just two dimensions.
# You can think of a 3 dimensional array as a collection
# of matrices.
# Function named array().

a <- array(rnorm(60), c(3,2,10),
           dimnames=list (
             paste("R", seq(1, 3), sep = ""),
             paste("C", seq(1, 2), sep = ""),
             paste("M", seq(1, 10), sep = "")
           )
);




a["R1","C2","M5"];   # vector with one value

a["R2","C2",];    # vector

a[,,"M6"];     # matrix


# Another way to make the same array.

rm(a);
a <- rnorm(60);
dim(a) <- c(2,3,10);
a;

class(a);

attributes(a);

str(a);

a[1,2,5];   # vector with just one value
a[2,2,];    # vector
a[,,6];     # matrix

class(a[1,2,5]);
class(a[2,2,]);
class(a[,,6]);    # matrix




