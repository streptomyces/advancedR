###############################
### Data Frames and tibbles ###
###############################

# Like two dimensional tables where columns are vectors.

# Columns can be of different types.

# All values in any one column have to be of the same type.

# All columns have to be of the same length.

# Commonly used for getting data into R from text files.

# Tibbles don't have row names.

##############################
### Reading MS Excel files ###
##############################

# Package named readxl provides functions for reading
# Microsoft Excel files.

# If the package readxl is not installed then you can
# install it by doing the following.

# install.packages("readxl");

rm(list = ls());

library("readxl");
library("tidyverse");

# Determine for format of the excel file. .xlsx or .xls
excel_format("data/file.xlsx")

# See names of sheets in the excel file.
excel_sheets("data/file.xlsx")


# Read the sheet named "hyphal_width".
hwt <- read_excel("data/file.xlsx", sheet = "hyphal_width")

# Read the first sheet in the file.
hwt <- read_xlsx("data/file.xlsx", sheet = 1)

hwt

class(hwt)

# Demonstrate consequences on not having a header in the
# excel spreadsheet.

nht <- read_excel("data/noheader.xlsx", sheet = "hyphal_width")
nht

nht <- read_excel("data/noheader.xlsx", sheet = "hyphal_width",
                 col_names = FALSE);
nht # Notice the column names.

# You can use colnames() to change the column names to more
# meaningful ones after getting your tibble.

colnames(nht) <- c("hw", "strain", "microscope");

# Or specify the column names in the call to read_excel().

nht <- read_excel("data/noheader.xlsx", sheet = "hyphal_width",
                 col_names = c("hw", "strain", "microscope"));

#########################
### Reading CSV files ###
#########################

# In the past I have had problems reading MS Excel files in
# R. In such cases you can write a csv from from Excel and
# then use read.csv() or read_csv() to read the csv file
# into a data frame or tibble.

# In MS Excel, after making sure that there is a line of
# header at the top, export your worksheet of interest
# as a csv file.

# Use read.csv() in R to read the csv file into a data
# frame. read.csv() assumes the presence of a header.

# Use read_csv() in R to read the csv file into a tibble.
# read_csv() also assumes the presence of a header.

# Some other named arguments to read.csv() which might
# be useful are stringsAsFactors and row.names. We will
# come to these later.

# data frame
hwf <- read.csv("data/hw.csv");
head(hwf);
nrow(hwf);

# tibble
hwt <- read_csv("data/hw.csv");
hwt;

# If your csv file or spreadsheet has no column names make
# sure you use "col_names = FALSE" or "header = FALSE".

nhf <- read.csv("data/noheader.csv");
head(nhf);
nrow(nhf);

nht <- read_csv("data/noheader.csv", col_names = FALSE);
nht;

colnames(nht) <- c("hw", "strain", "microscope");

#################################
### Do the following yourself ###
#################################

# The sheet named "expression" in the file data/file.xlsx
# contains the columns named "gene", "control" and
# "treatment".

# 1. Read this sheet into a tibble named "expt";

# 2. Try the commands colnames(), nrow(), ncol()
# with expt as the only argument.

# 3. Try the command class(expt).

# 4. How will you change the column names "control" to "WT"
# and "treatment" to "dwhiG"?


