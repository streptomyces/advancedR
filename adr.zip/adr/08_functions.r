#################
### Functions ###
#################

# Functions do things for us.

# Need arguments to work on.

# May assume default arguments if none are provided.

# May return something which you may wish to store as a
# new object.

# If you are not assigning the returned value to an object
# then the returned value may be printed on the console.
# invisible()

# Some functions are used primarily for their
# side-effects rather than their return value.

# User defined functions.

rm(list = ls());

bmi <- function(kilograms, metres) {
  return(kilograms / metres ** 2);
}

bmi(65, 1.65);

### Components of functions ###

#  1. Formal argument list.
#  2. Body
#  3. Environment

### Arguments

# Arguments are values or objects a function acts on. The
# process of getting arguments into functions is called
# argument passing.

# Supplied arguments are matched to formal arguments in a
# three pass process.

#  1. Exact matching on tags
#  2. Partial matching on tags
#  3. Positional matching.

# We will use the seq() function of R as an example.

# positional arguments
seq(2, 10);

seq(2, 10, 2);

# Positional and named arguments
seq(2, 10, by = 2);

# Named arguments only
seq(from = 2, to = 10, by = 2);

# Positional and named arguments
seq(2, to = 10, by = 2);

# Positional and named arguments
seq(2, by = 2, 10);

# Partial matching of argument names
seq(2, fr = 4, to = 20);


#######################################
### Calling bmi() is different ways ###
#######################################
bmi(65, 1.68);
bmi(kilograms = 65, metres = 1.68)
bmi(metres = 1.68, kilograms = 65)
bmi(kilo = 65, met = 1.68)
bmi(m = 1.68, k = 65)
bmi(m = 1.68, 65)


####################################
### Return values from functions ###
####################################

# If a function returns something and you want to keep it
# you have to assign it to a (new) object.

x <- seq(2, 10);
x;
y = seq(3, 30, by = 3);
y;


# Some functions do not return anything (NULL).
x <- seq(10, 100, by = 5);
cat(x, "\n");
catret <- cat(x, "\n");
catret;

# Demonstrate invisible here.

bmii <- function(kilograms, metres) {
  invisible(kilograms / metres ** 2);
}

bmi(m = 1.65, 65);
bmii(m = 1.65, 65);
bmx <- bmii(m = 1.65, 65);
bmx

##############################################
### A note about assignment operators in R ###
##############################################

x <- seq(10, 100, by = 5);
x
# Works, but for the wrong reason.
x <- seq(10, 100, by <- 5);
x

# Fails. Wrong sign in by argument.
rm(x);
x <- seq(10, by <- 5, 100);
x

# Works. But unintended result.
rm(x);
x <- seq(10, by <- 5, -1);
x

# Alt-minus key combination gives you the
# assignment operator in RStudio
 
# Use <- or = on the command line.
# Always use = in function calls and function definitions.

# Function calls as arguments

rep(4, times = 4);

rep(seq(1,4), times = 4);

rep(seq(1,4), each = 4);

#################################
### Do the following yourself ###
#################################

# 1. Run the code below.
#
x <- y <- z <- 42
#
# 2. Check the values of x, y and z.


# 1. Generate the sequence -20 to 50 increasing in steps
# of 5 and name it ds.

# 2. Check the value of ds.

######################################################

# 1. Write a function named cel2fah which takes one
# argument, the temperature in degrees Celsius, and returns
# the same temperature in Fahrenheit.

# 2. Hints:
# - Multiply Celsius by 1.8 then add 32 to get Fahrenheit.

### Write your function here ###


# 3. Test your function by calling it as below.

#    a. cel2fah(100)
#    b. cel2fah(0)
#    c. cel2fah(seq(0,100))

# Discuss call c. above.

# You cannot do cel2fah(0,10).

# 4. Try the below.

curve(cel2fah, -50, 50, xlab = "Celsius",
      ylab = "Fahrenheit", lwd = 3, col = "royalblue")

# Functions are objects. We passed a function as an argument
# to another function.

class(cel2fah)
typeof(cel2fah)

# Another example of passing a function as an argument to
# another function. Trignometric functions such as sin()
# or cos() take their arguments in radians. But I am more
# comfortable thinking in degrees.

deg2rad <- function(deg) {
return(deg * 2 * pi / 360);
}
curve(sin, deg2rad(0), deg2rad(360), col = "red", lwd = 3,
      ylab = "f(x)", xlab = "x in radians");
curve(cos, deg2rad(0), deg2rad(360), col = "blue", lwd = 3, add = T);


########################
### ... (three dots) ###
########################

dotdemo1 <- function(x, ...) {
  cat("x is: ", x, "\n");
  vargs <- list(...);
  cat("Then: ", vargs[[1]], "\n");
}
dotdemo1("stuff", "morestuff");


dotdemo2 <- function(x, ...) {
  cat("x is: ", x, "\n");
  vargs <- list(...);
  cat("y as named: ", vargs$y, "\n");
  cat("y as positional: ", vargs[[1]], "\n");
  cat("Then: ", vargs[[2]], "\n");
}
dotdemo2(x = "stuff", y = "morestuff", 23);


##############################
### Operators as functions ###
##############################

x <- 2;
y <- 3;

x + y

'+'(x,y)
'*'(x,y)

vecx <- c(2.9, 4.1, 3.9, 4.5, 3.7, 45.3, 21.6);
z <- c("ftsZ", "sigE", "bldN", "whiA", "whiB", "rdlA", "chpA");
names(vecx) <- z;

'['(vecx, 4);
'['(vecx, "whiA");


