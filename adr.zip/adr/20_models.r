#########################################
### Statistical Models in R (skipped) ###
#########################################

# Normal
# rnorm(): random generation function
# pnorm(): probability density function
# dnorm(): density function
# qnorm(): quantile function
# Similarly for uniform, binomial, gamma, t, etc.

### Example: Normal distribution.

rm(list = ls());

x <- rnorm(500, mean = 15, sd = 5);

pnorm(35, mean = 15, sd = 5);  # P(X <= 35).

pnorm(35, mean = 15, sd = 5, lower.tail = FALSE);  # P(X > 35)

dnorm(seq(1,10), mean = 5, sd = 1)


###### Begin ignore ######

# Below is to generate plots for explaining. We will see
# some of these functions later we cover plotting. For now,
# simply ignore.

par(mfrow = c(2,1), bg = "lightgrey");
bar <- 15; xsd <- 3;
ddn <- function(x) {
  return(dnorm(x, mean = bar, sd = xsd))
}
cfrom <- bar - 4 * xsd;
cto <- bar + 4 * xsd;
curve(ddn, from = cfrom , to = cto, add = FALSE, lwd = 3,
      main = paste("Mean:", bar,  "and SD:", xsd),
      ylab = "Density",
      xlab = "x"); grid(col = "black");
ppn <- function(x) {
  return(pnorm(x, mean = bar, sd = xsd, lower.tail = FALSE))
}
ppnlt <- function(x) {
  return(pnorm(x, mean = bar, sd = xsd, lower.tail = TRUE))
}
curve(ppn, from = cfrom , to = cto, add = FALSE, lwd = 3,
      col = "darkred", ylab = "Probability", xlab = "x")
curve(ppnlt, from = cfrom , to = cto, add = TRUE, lwd = 3,
      col = "darkgreen")
grid(col = "black")
legend(cfrom, 0.9, "lower.tail FALSE", fill = "darkred", bty = "n")
legend(cfrom, 0.8, "P(X > x)", bty = "n")
legend(cto, 0.9, "lower.tail TRUE", fill = "darkgreen", bty = "n", xjust = 1)
legend(cto, 0.8, "P(X <= x)", bty = "n", xjust = 1)

###### End ignore ######

#################################
### Do the following yourself ###
#################################

# 1. Generate 2000 normally distributed random numbers
# from a population where the mean is 18 and standard
# deviation is 3 and keep them in a vector named x.

# 2. Confirm that x has 2000 elements without listing
# them all.

# 3. Find the minimum, maximum, mean and median of x.

# 4. The function for standard deviation is sd. Use this
# function to find the standard deviation of x. Should
# be approximately 3.

# 5. The function for square root is sqrt. Standard
# error of the mean (SEM) is calculated as the SD
# divided by the square root of the sample size. Without
# using any object other than x, find the SEM. Should
# be approximately 0.06.


