###############
### Vectors ###
###############

# Ordered collection of values.

# Contiguous cells containing data.

# All values have to be of the same type.

# They can hold values of any of the basic types.

# One way of making a vector is by using the c() function.
# (concatenate).

x <- c(10, 20, 30)

# Cells are accessible through subscripting / indexing.
# e.g. if vector x contains 10, 20 and 30 then

x[1] # refers to 10,
x[2] # refers to 20 and,
x[3] # refers to 30

# Indexing begins from one, not zero.


x <- c(2.9, 4.1, 3.9, 4.5, 3.7, 45.3, 21.6);

x;

x[1];

x[7];

x[4:6]   # ":" is the range operator. Step by 1 only.


# The simplest data type in R is a vector.

y <- 5.4; # is the same as y <- c(5.4);

y;

y[1];

z <- c("ftsZ", "sigE", "bldN", "whiA", "whiB", "rdlA", "chpA");
z;
z[3];

length(x)
length(z)


### Named Vectors ###

# Elements of a vector can be named

names(x) <- z;
x;

x["whiA"]; # is the same as x[4];

v <- c("whiA", "rdlA");

x[v];

#################################
### Do the following yourself ###
#################################

# 1. Make the vectors x and z as discussed above.

x <- c(2.9, 4.1, 3.9, 4.5, 3.7, 45.3, 21.6);
z <- c("ftsZ", "sigE", "bldN", "whiA", "whiB", "rdlA", "chpA");

# 2. Name the elements of x as the strings in z.

# 3. Examine the output of

unname(x)

# 4. Make a copy of x in vecx. We will use it in the next
# script.



