###############
### Factors ###
###############


# Think of them as categories.

rm(list = ls());

numbers <- c(1.200261, 1.479827, 1.482392, 1.716793, 1.518791, 1.000030,
             1.933209, 1.841415, 1.315890, 1.849663);

category <- c("A", "A", "B", "B", "B", "A",
              "C", "C", "A", "B");

f <- factor(category);

typeof(category);

class(category);

typeof(f);

class(f);

#####################################################
  
tapply(numbers, f, mean);

tapply(numbers, category, mean);

levels(f);

levels(category)


# Allow you to assign individual elements of a vector to
# groups or categories.

# Using factors you can do calculations such as mean(),
# sd() etc. on a group-by-group basis.

#################################
### Do the following yourself ###
#################################

rm(list = ls());

hwf <- read.csv("data/hw.csv", stringsAsFactors = TRUE);
head(hwf);
nrow(hwf);

# 1. Find out the class of hwf$strain.

# 2. Determine the number of distinct strains in hwf.

# 3. Use tapply() to calculate the mean of the hyphal
# widths for each of the strains in hwf.

# 4. Use tapply() to calculate the standard deviation of
# the hyphal widths for each of the strains in hwf.


### Tidyverse style ###

# Tidyverse functions read_excel and read_csv etc. do not
# make factors when they read data in. If you need to, you
# can convert the columns you want to factors as below.
# read_csv() has an option (col_types) to let you specify
# column types when you are reading data in.

hwt <- read_csv("data/hw.csv");
hwt;

mutate(hwt, strain = factor(strain),
       microscope = factor(microscope))

# group_by() and summarise() by piping
group_by(hwt, strain) %>%
summarise(grmean = mean(hw));

group_by(hwt, microscope) %>%
summarise(grmean = mean(hw));

# Via an intermediate object.
bygr <- group_by(hwt, strain);
summarise(bygr, grmean = mean(hw));


