################################
### Calculating a new column ###
################################

# The file data/expression.csv has the same contents as the
# "expression" sheet of file.xlsx.

rm(list = ls());

data <- read.csv("data/expression.csv", header = TRUE, row.names = 1)
head(data)
nf <- cbind(data, logFC = data$treatment - data$control)
head(nf)


#################################
### Do the following yourself ###
#################################

# 1. Instead of getting a new data frame as above, you
# can assign a new column to your original data frame
# (named "data" in this case). This is done by assigning
# a vector to a new column name. Delete data then read
# the file into the data again. Now add a column named
# logFC to data by directly assigning to data$logFC.


# 2. Confirm that "logFC" column has been added to data.


# 3. The products of all the genes in "data" are written
# in the file "products.csv".


# 4. Read the file "data/products.csv" into a data frame
# named temp. Use the named arguments row.names = 1,
# stringsAsFactors = FALSE.


# 5. Add the product column from temp to data but keep
# in mind that the order of genes in temp is not the
# same as in data. Hint: Use rownames(data) to subset
# temp.

# 6. After making sure that "data" is as resuired run the
# following.

saveRDS(data, file = "data.rds");

###################
### dplyr style ###
###################

tib <- read_csv("data/expression.csv", col_names = TRUE);

tib1 <- mutate(tib, logFC = treatment - control);
tib1

# Or, we could simply overwrite tib.

tib <- mutate(tib, logFC = treatment - control);
tib

# dplyr joins #

temptib <- read_csv("data/products.csv")
temptib
left_join(tib, temptib, by = "gene")

# Unwanted column in temptib

temptib <- mutate(temptib, unwanted = rep("unwanted",
                  nrow(temptib)));
temptib
left_join(tib, temptib, by = "gene")
left_join(tib, select(temptib, gene, product),
                  by = "gene")

### Piping ###
# Useful for discarding intermediate objects.
# Easier to apply on several objects.

select(tib, gene, logFC) %>% 
  left_join(select(temptib, gene, product), by = "gene")

tib <- tib %>% left_join(select(temptib, gene, product),
                         by = "gene")
tib;

saveRDS(tib, file = "tib.rds");


