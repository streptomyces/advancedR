##########################
### Specifying colours ###
##########################

# Using the 10 digits in base 10 (0 to 9), the highest
# two digit number we can express is 99.

10^2

### Counting in base 16 (hexadecimal or hex) ###

# Using 16 digits in base 16 (0 to 9 then A to F), the
# highest two digit number we can express is 255.

16^2

# 0 decimal is 00 in hex and 255 decimal is FF in hex.

# In binary, we need 8 bits (one byte) to count upto
# 255.

2^8

# So two hex digits can be used to express all the
# values possible using a single byte (0 to 255)

#  Colours are made by mixing red, green and,
#  blue channels.

#  Each channel can be anything from 0 to 255
#  (00 to FF in hex).

# An alpha channel can be added for controlling
# transparency of the colour.

#  Be careful with the spelling of colo(u)r.

# The R function rgb() lets you generate colours without
# the need to think in hex or even on a scale of 0 to
# 255.

# Fully opaque red.
rgb(255,0,0, maxColorValue = 255);
rgb(255,0,0,255, maxColorValue = 255);

# Fully opaque green. maxColorValue defaults to 1.
rgb(0,1,0, maxColorValue = 1);
rgb(0,1,0,1, maxColorValue = 1);

# Find it easier to think in percent?
rgb(0,100,0, maxColorValue = 100);
rgb(0,100,0,100, maxColorValue = 100);

barplot(c(1,2), col = c(
  rgb(100,100,0, maxColorValue = 100),
  rgb(0,100,100,100, maxColorValue = 100)
));  


reds <- seq(0.1, 1, 0.05);
greens <- seq(1, 0.1, -0.05);
blues <- c(0);

colmix <- rgb(reds, greens, blues);
names(colmix) <- paste("CO", seq(1, length(colmix)), sep = "");
colmix
ht <- runif(19, min = 5, max = 20)
barplot(ht, col = colmix)


### Colour ramp function generator ###

blured.ramp <- colorRampPalette(c(rgb(0,0,1,1), rgb(1,0,0,1)),
                           alpha = TRUE);

blured.ramp <- colorRampPalette(c("blue", "red"),
                           alpha = TRUE);

class(blured.ramp);
typeof(blured.ramp);

blured.ramp(19)
ht <- runif(19, min = 5, max = 20)
barplot(ht, col = blured.ramp(19))


# colorRampPalette(c(rgb(0,0,1,1), rgb(1,0,0,1)), alpha = TRUE)(19)



