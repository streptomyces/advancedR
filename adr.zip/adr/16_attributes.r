##################
### Attributes ###
##################

# Objects can have attributes attached to them.

# Think of them as arbitrary name = value pairs.

# attributes()

# attr()

# The following are used by R.

# 1. Names. names().

# 2. Dimensions. dim(). Matrices and Arrays which we
# will see later on are vectors with the dim attribute
# attached to them.

# 3. Dimnames. dimnames(). If dimensions are named
# the names are stored in the dimnames attribute of the
# array or matrix.

# 4. Class. class(). The name of the class an object
# belongs to is stored in and attribute named class.

###################################################
### Step and think through the statements below ###
###################################################

x <- seq(1,10);
x
class(x);
class(x) <- c(class(x), "adr");
class(x);

attr(x, "purpose")
attr(x, "purpose") <- "testing";
attr(x, "purpose")
attr(x, "purpose") <- c(attr(x, "purpose"), "training")
attr(x, "purpose")

attributes(x);


