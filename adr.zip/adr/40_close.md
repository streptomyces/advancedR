* A general purpose programming language such as Perl or
  Python is very useful for tidying up data before reading
  into R.

* Ability to read documentation quickly is more important
  than you think. Not just in R.

* Write and use functions a lot. In addition to making
  repetitive tasks easier, they provide safety against
  inadvertent variable values because they have their own
  scope.

* [R manuals webpage](https://cran.r-project.org/manuals.html)

* [PDF of the Introduction to R book](https://cran.r-project.org/doc/manuals/r-release/R-intro.pdf)

* [Tidyverse (dplyr, tibbles, ggplot and more) documentation](https://www.tidyverse.org/)

* [RNA-Seq data analysis using edgeR](https://f1000research.com/articles/5-1438)

