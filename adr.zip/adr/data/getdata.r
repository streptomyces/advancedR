setwd("u:/");
# unlink("Rtrain", recursive = TRUE);
# dir.create("Rtrain");
setwd("Rtrain");

# getwd();
# unlink("*");
# list.files();

download.file("http://streptomyces.org.uk/customers/training/aar/data.zip",
"data.zip", "internal");

# list.files();

unzip("data.zip");

# list.files();
