x <- rnorm(500);

sink("sink.txt", type = c("output"));
summary(x);

hist(x);

sink();

