# R CMD BATCH --vanilla --silent --slave cmd.r cmd.stdout;

idf <- read.table(file = "header2.tsv", sep = "\t", stringsAsFactors = FALSE,
                  row.names = 1, header = TRUE);


cat("Read header2.tsv\n");

idf$lfc <- idf$treatment - idf$control;

odr <- order(abs(idf$lfc), decreasing = TRUE);

odf <- idf[odr,];
head(odf);

write.table(odf, file = "cmd.out", sep = "\t", quote = FALSE);

cat("Written cmd.out\n");


