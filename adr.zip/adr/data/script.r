# Run as
# Rscript script.r dfops.csv scriptout.csv

# Explain processing for command line arguments here.

args <- commandArgs(trailingOnly = TRUE);
# args <- commandArgs();

cat(args, "\n");

infile <- args[1];
outfile <- args[2];

cat(infile, outfile, "\n");

idf <- read.csv(file = infile, row.names = 1, header = TRUE);

cat("Read", infile, "\n");

head(idf);

idf$lfc <- idf$treatment - idf$control;

odr <- order(abs(idf$lfc), decreasing = TRUE);

odf <- idf[odr,];
head(odf);

write.csv(odf, file = outfile);

cat("Written", outfile, ".\n");

