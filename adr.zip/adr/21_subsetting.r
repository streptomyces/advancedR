##############################
### Subsetting data frames ###
##############################

### Subscripts are used to get subsets of data frames
#   (and other types of objects) in R.

df <- data.frame(x = runif(26, min = 3, max = 12),
                 y = runif(26, min = 30, max = 120));
rownames(df) <- LETTERS;
head(df);

# dataframe[rownum, colnum]

df[3, 2]

# dataframe["rowname", "colname"]

df["C", "y"]

### You get all columns if no columns are specified.
# dataframe[rownum, ]
# dataframe["rowname", ]

df[5,]
df["E",]

### You get all rows if no rows are specified.
# dataframe[, colnum]
# dataframe[, "colname"]

df[, "x"]
df[, 1]

### Rows and columns may be specified as vectors.

rows <- seq(17,24);
coln <- c(1);
df[rows, coln];

colhead <- c("x");
df[rows, colhead];

### The dollar notation can only be used with single column names.
#   This is actually very common.
# dataframe$colname

df$x 


### If you ask for multiple columns you always get a data frame in return.
#   Even if you have asked for a single row.

df[c(1,2,3), c("x", "y")]
df[2, c("x", "y")]

### Single columns are returned as vectors.

#################################
### Do the following yourself ###
#################################

# 1. Make a vector, ronum, containing the numbers 21 to 30
# and 51 to 60 by concatenating (remember c()?) two
# calls to seq().

# 2. Use the vector ronum, made above to get a subset data
# frame from hwf consisting of only row numbers in ronum

# 3. From hwf, extract the strain associated with the
# hyphal width in row number 58 and store it in a vector
# named strain58. Check the class and mode of strain58.


### Tidyverse style ###

slice(hwt, ronum);

# hwt[ronum,] # also works.

hwt[58, "strain"]



