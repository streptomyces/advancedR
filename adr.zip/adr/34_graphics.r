#####################
### Base graphics ###
#####################

# Several commands, plot(), boxplot(), points(), lines(),
# abline() and several others.

# plot() is usually the starting function call.

# points(), lines(), abline() etc. can add to the plot
# initially made by plot.

# plot() can behave differently depending upon what
# arguments are passed to it.

graphics.off()
x <- rnorm(1000, mean  = 20, sd = 2);
plot(x);
boxplot(x);

m <- matrix(x, nrow = 200, ncol = 5);
plot(m[,1], m[,2]);

plot(m[,1], m[,3]);

boxplot(m)



