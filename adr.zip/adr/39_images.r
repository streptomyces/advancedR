###############
### EBImage ###
###############

library("EBImage");

options(EBImage.display = "raster");

cfinch <- readImage("data/goldfinch.jpg");
gfinch <- readImage("data/grayfinch.jpg");

cfinch
gfinch



dev.print(jpeg, filename = "copy.jpg", width = dim(hhock)[1],
height = dim(hhock)[2], quality = 70);


