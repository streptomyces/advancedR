###############
### EBImage ###
###############

# The package EBImage can handle png, jpeg and tiff file
# formats. Once an image is read in, it allows access to
# individual pixels and also the manipulation of the entire
# image using a matrix / array like interface.

library("EBImage");

options(EBImage.display = "raster");
# The other option is "browser".

finch <- readImage("data/goldfinch.jpg");
finch

### Brightness

dark1 <- finch - 0.1;
dark2 <- finch - 0.2;
par(mfrow = c(2,2));
display(finch);
display(dark1);
display(dark2);

### Image object to file

writeImage(dark1, "../darkfinch.jpg", "jpeg", quality = 70) 

### Cropping

headfinch <- dark1[100:500, 10:180,]
display(headfinch);

### Adding text to image

# x11(type = "cairo");
windows();
par(mfrow = c(1,1));
display(dark1)
text(650, 30, labels = "Goldfinch on wire", col = "#eeeeee",
cex = 1.5);

### Display to file

dev.print(jpeg, filename = "../annofinch.jpg", width = dim(dark1)[1],
height = dim(dark1)[2], quality = 70);

### Separating channels

reds <- channel(finch, "red");
greens <- channel(finch, "green");
blues <- channel(finch, "blue");

par(mfrow = c(3,1));
display(reds);
display(greens);
display(blues);

#################################
### Do the following yourself ###
#################################

# The function rgbImage takes the three channels as
# the first three arguments and combines them to produce a
# colour image.

# 1. Read the image "data/mallards.jpg".

# 2. Separate the three channels.

# 3. Add 0.12 to the blue channel.

# 4. Combine the three channels to get a color image using
# the function rgbImage();

# 5. Display both the original image and the modified image.

mallards <- readImage("data/mallards.jpg");
reds <- channel(mallards, "red");
greens <- channel(mallards, "green");
blues <- channel(mallards, "blue");

blues <- blues + 0.12;

mallards2 <- rgbImage(reds, greens, blues);

par(mfrow = c(1,2));
display(mallards);
display(mallards2);

dev.off();

