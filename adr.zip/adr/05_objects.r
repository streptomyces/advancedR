#######################
### Data structures ###
#######################

# Types which are combinations of the basic data types.

# Can be arbitrarily complex.

# Several provided by R as classes.

###############
### Classes ###
###############

# Data structures with associated functions (methods).

# A class is a recipe for making objects and "constructor"
# methods are usually provided.

###############
### Objects ###
###############

# Objects are "instances" of classes.

# Objects of a class have all the methods of the class
# available to them.

# Objects can be of more than one class. Then they have
# methods of all the classes available to them.

# There are no simple variables in R. Everything is an object i.e.
# belongs to one class or another.

# Even if you need to store just one value you use an object
# that is capable of storing multiple values.

# Function ls() will list all objects in existence.

ls()

#########################
### Generic Functions ###
#########################

# Assume an object O belonging to class C.

# When a function like plot(O) or print(O) is called it
# looks for a function named print.C or plot.C and runs it.
# If this is not found then print.default or plot.default is
# run.

methods(plot)


