#######################
### Data structures ###
#######################

# Types which are combinations of the basic data types.

# Can be arbitrarily complex.

# Several provided by R as classes.

###############
### Classes ###
###############

# Data structures with associated functions (methods).


# A class is a recipe for making objects and "constructor"
# methods are usually provided.

###############
### Objects ###
###############

# Objects are "instances" of classes.

# Objects of a class have all the methods of the class
# available to them.

# Objects can be of more than one class. Then they have
# methods of all the classes available to them.

# There are no simple variables in R.

# Even if you need to store just one value you use a data
# structure that is capable of storing multiple values.


