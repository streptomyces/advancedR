##############################
### Scope and Environments ###
##############################

# Lexical scope: Functions are evaluated in the environment
# in which they are defined.
#
# The environment provides values for any unbound symbols in
# a function when the function is evaluated.

funcgen <- function(g = 9.8) {
  time2ground <- function(height = 1, initial = 0) {
    fvsq <- (initial ** 2) + (2 * g * height);
    final = sqrt(fvsq);
    t2g = (final - initial) / g;
    return(t2g);
  }
  return(time2ground);
}

ttg.earth <- funcgen(9.8);  # function
ttg.mars <- funcgen(3.72);  # function

ttg.earth(10);
ttg.mars(10);

curve(ttg.mars, 0, 10, col = "red", lwd = 3,
xlab = "Height", ylab = "Time to ground")
curve(ttg.earth, 0, 10, add = TRUE, col = "blue", lwd = 3)

mars <- environment(ttg.mars);
earth <- environment(ttg.earth);
parent.env(mars);
parent.env(earth);
environment(funcgen);

g <- 20;
get("g");
get("g", envir = .GlobalEnv);

get("g", envir = earth);
get("g", envir = mars);

ls(envir = earth);
rm("g", envir = earth);
ls(envir = earth);
curve(ttg.earth, 0, 10, add = TRUE, col = "darkolivegreen3", lwd = 3)
assign("g", 9.8, envir = earth);
ls(envir = earth);

# The effective environment is almost always a nesting of
# environments.

#################################
### The search path. search() ###
#################################

time2ground(10);

search();

attach(earth);

search();

time2ground(10);



