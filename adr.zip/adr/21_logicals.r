##################
### Truth in R ###
##################

rm(list = ls());

x <- rnorm(10, mean = 5, sd = 1);
x;

x <= 5;
x > 5;

g <- x <= 5;
g

# There is a data type called "logical".

typeof(g);

x[g];

#############################################################

### any() and all() ###


any(g);
all(g);

fl <- as.integer(c(1, 2, 3, 4, 5, -6));
any(fl);
all(fl);

fl <- as.integer(c(1, 2, 3, 4, 5, 0));
any(fl);
all(fl);

fl <- as.integer(c(-1, 0, 0, 0));
any(fl);
all(fl);

### Strings cannot be used as logicals.

s <- c("str1", "", "str3");

as.logical(s);         # NA

####################################
### Testing for numeric equality ###
####################################

x <- seq(1,10, by = 0.25);
y <- x;

x == y;
identical(x,y);
all.equal(x,y);


# Divide x by pi then multiply the result by pi
z <- x / pi
x <- z * pi

### identical() and all.equal()
x == y;
identical(x,y);
all.equal(x,y);

###### End of Day 1 ######

# all.equal() never returns FALSE. It either returns TRUE or a string.

x <- rnorm(10, mean = 5, sd = 0.0001);
y <- rnorm(10, mean = 5.0001, sd = 0.0001);

# Below returns a string or TRUE
all.equal(x,y);
all.equal(x,y, tolerance = 1e-4);


# Below return FALSE or TRUE
isTRUE(all.equal(x,y));
isTRUE(all.equal(x,y, tolerance = 1e-4))


# It might be best to decide how much difference you are
# willing to ignore and then do something like below.

any(abs(x-y) > 1e-3)
any(abs(x-y) > 1e-4)
x
y
abs(x - y)

#################################
### Do the following yourself ###
#################################

# 1. Store the value of 0.5 - 0.3 as m

# 2. Store the value of 0.3 - 0.1 as n

# 3. Use == to test the equality of m and n.

# 4. Use identical() to test the equality of m and n.

# 5. Use all.equal() to test the equality of m and n.

# 6. What is the output of isTRUE(all.equal(m,n))?

# Refer to the documentation of all.equal() to find out
# the default value of the tolerance argument.

#############################################################
#############################################################

# Use isTRUE(all.equal()), not ==, when comparing floating
# point numbers.


