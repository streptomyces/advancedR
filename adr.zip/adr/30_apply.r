######################
### apply() et al. ###
######################

### apply() ###

rm(list = ls());

# Make a matrix

set.seed(20230201); # So that we have the same random numbers.
x <- runif(24, min = 20, max = 30)
dim(x) <- c(4, 6);
x

d <- as.data.frame(x);
d


# Define a function to be applied later.

apfun <- function(arg1) {
return(arg1 - mean(arg1));
}

# Apply the function to each row of x

apply(x, 1, apfun);
apply(d, 1, apfun);

# Each application results in a column in the returned matrix.
# Hence the transpose below.

t(apply(x, 1, apfun));
t(apply(d, 1, apfun));

# Apply the function to each column of x

apply(x, 2, apfun);
apply(d, 2, apfun);

# You still get one column per application.

# If each application returns a single value then
# apply returns a vector.
# The option simplify is TRUE by default.

apply(x, 2, FUN = apfun, simplify = T);

# Below gives a list with one element for each application
# of FUN
apply(x, 2, FUN = apfun, simplify = F);


### lapply() and sapply() ###
# Apply a function over a List or a Vector.
# sapply() tries to simplify the return value to a vector or
# matrix.

lapply(x, apfun) # Matrices are vectors with dimensions!
sapply(x, apfun) # Matrices are vectors with dimensions!

# Data frames are lists of columns.
lapply(d, apfun)
sapply(d, apfun) # Same as apply(d, 2, apfun);

lapply(d, mean)
sapply(d, mean)

### tapply() ###

# We saw this when doing Factors.

hwt <- read_csv("data/hw.csv");

tapply(hwt$hw, hwt$strain, mean);
tapply(hwt$hw, hwt$strain, sd);
tapply(hwt$hw, hwt[, c("strain", "microscope")], mean);

### aggregate() ###

aggregate(hwt$hw, by = list(hwt$microscope, hwt$strain),
FUN = mean);

# There are NAs in the microscope column.
print(hwt[49:60,], n = 30)

mm <- hwt$microscope
mm[is.na(mm)] <- "U";
hwt <- hwt %>% mutate(microscope = mm)
print(hwt[49:60,], n = 30)

aggregate(hwt$hw, by = list(hwt$microscope, hwt$strain),
FUN = mean);

#################################
### Do the following yourself ###
#################################

# When writing functions you can set the defaults of some
# options which will be used if no arguments are provided
# for the options.

# Write a function named by.n which returns the first
# argument divided by the second argument. If the second
# argument is not provided then it defaults to 2.

by.n <- function(x, n = 2) {
### write this part ###
}

# Apply the above function to the columns of the data frame
# d made above.

# How will you get one fourth of all values in d?

