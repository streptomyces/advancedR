###############
### ggplot2 ###
###############

# Part of a collection of packages called tidyverse.

# The "gg" in ggplot2 stands for Grammar of Graphics.

# Much more structured and formal than the collection of
# graphics commands in base R.

### Three essential components of a ggplot ###

# 1. Data. Usually a dataframe or a tibble.

# 2. Aesthetic mappings. Think of them as mapping of
# data to axes and colour and shape of points. Function:
# aes().

# 3. Layers. Actual rendering on the plotting device.
# Functions: geom_*(). The kind of plot you want.
# Multiple layers are allowed and indeed, common.

### Function ggplot() ###

# Usually called with two arguments, data and aesthetic
# mapping.

# Data, of course, is your dataframe and you get an
# aesthetic mapping by calling aes(). Calls to aes() can
# be used as argument to ggplot() or to geom_*(). If
# included in ggplot() the values are inherited by all
# layers.

### Layers ###

# To the result of the call to ggplot() we can add
# layers.

### Theme ###

# Function theme().

# Control the overall appearance of a plot.


rm(list = ls());
df <- read.csv("data/tfaG.csv");
head(df);

ggplot(df) +
  geom_point(aes(hour, wt), colour = "red") +
  geom_point(aes(hour, tfaG), colour = "blue")

p1 <- ggplot(df)
p1 + geom_point(aes(hour, wt), colour = "red")
p1 + geom_point(aes(hour, tfaG), colour = "blue")

p1 + geom_point(aes(hour, wt), colour = "red") + 
  geom_point(aes(hour, tfaG), colour = "blue")

p1 + geom_path(aes(hour, wt), colour = "red") + 
  geom_path(aes(hour, tfaG), colour = "blue")



p2 <- p1 +
geom_path(aes(hour, wt), colour = "darkred", size = 1.2) +
geom_path(aes(hour, tfaG), colour = "blue", size = 1.2) +
geom_point(aes(hour, wt), colour = "darkred", size = 3) +
geom_point(aes(hour, tfaG), colour = "blue", size = 3) +
xlab("Hours of growth") +
ylab("Log2 expression") +
ggtitle("Expression of spoF in wt and tfaG deletion strains") +
theme_bw() +
theme(plot.title = element_text(size = 24, face = "bold",
                                hjust = 0.5)) +
theme(axis.title = element_text(size = 15, face = "bold",
                                vjust = 0.5)) +
theme(axis.text = element_text(size = 12, face = "plain",
                                vjust = 0.5))

graphics.off()
p2


# The above is not the best way to organise your data for
# ggplot2. If you have a dataframe like.
# 
#   hour       wt     tfaG
# 1    1 2.597158 2.830137
# 2    2 2.636187 2.800135
# 3    3 2.837971 2.917881
# 4    4 2.711013 2.703749
# 5    5 2.882070 2.838809
# 6    6 2.724614 2.028673


# Reform it to something like this.

#     hour strain  logexpr
# 1      1     wt 2.597158
# 2      2     wt 2.636187
# 3      3     wt 2.837971
# ...
# 118   58   tfaG 2.246144
# 119   59   tfaG 2.755333
# 120   60   tfaG 2.775126

# Think like this: everything on the x-axis goes in one
# column no matter how many categories those values
# belong to. The categories can be specified in other
# columns. Similarly for the values intended for the
# y-axis.


# Below is one way of getting from df to gdf.
#
# There may be functions in available packages to do
# this.

gdf <- data.frame(hour = rep(df$hour, 2),
      strain = c(rep(colnames(df)[2], 60),
      rep(colnames(df)[3], 60)),
      logexpr = c(df$wt, df$tfaG)
)
head(gdf)
class(gdf$strain)

### Plotting begins ###

ggplot(gdf, aes(hour, logexpr, colour = strain)) +
  geom_point() +
  geom_path() +
  theme_bw()


ggplot(gdf, aes(hour, logexpr, colour = strain)) +
  geom_point(size = 3) +
  geom_path(size = 1.2) +
  theme_bw()


### We will save the plot objects as we build them.
# gdfcols <- c("#129628", "#961254");
p1 <- ggplot(gdf, aes(hour, logexpr, colour = strain,
                      shape = strain))
p2 <- p1 + geom_point(size = 3) +
  geom_path(size = 1.2)
p2
# scale_colour_manual(values = c(gdfcols))


# Axis labels and grid lines.

p2 +
  scale_x_continuous(name = "Hours of growth") +
  scale_y_continuous(name = "Log2 expression")

xbr <- seq(0, 60, by = 5)
p3 <- p2 +
  scale_y_continuous(name = "Log2 expression") +
  scale_x_continuous(name = "Duration of culture",
                     breaks = xbr,
                     labels = paste0(xbr, "h"))

p3


# Legend

# p4 <- p3 + scale_colour_discrete(name = "spoF expression in",
#                            labels = c("tfaG deletion strain",
#                                      "Wild type strain"))

# p4


# Our colours

# p3 + labs(colour = "Strain", shape = "Strain")

gdfcols <- c("#129628", "#961254");
# gdfcols <- c("darkblue", "red");
p5 <- p3 + scale_colour_manual(name = "Strain id",
   values = gdfcols,
   labels = c("tfaG deletion strain",
   "M600")) +
scale_shape_discrete(name = "Strain id",
   labels = c("tfaG deletion strain",
   "M600"))

# p3 + labs(colour = "Strain", shape = "Strain")


p5

# Main title

p6 <- p5 + 
ggtitle("Expression of SpoF in M600 and tfaG deletion strains\nover 60 hours of growth in shaken flask");
p6

# Theme
p7 <- p6 +
  theme_bw() +
  theme(plot.title = element_text(size = 24, face = "bold",
                                  hjust = 0.5)) +
  theme(axis.title = element_text(size = 18, face = "bold",
                                  vjust = 0.5)) +
  theme(axis.text = element_text(size = 15, face = "plain",
                                 vjust = 0.5)) +
  theme(legend.text = element_text(size = 15, face = "bold",
                                   hjust = 0.5)) +
  theme(legend.key.size = unit(15, "mm")) +
  theme(legend.title = element_text(size = 18, face = "bold",
                                    hjust = 0.5)) +
  theme(plot.margin = margin(1, 1, 1, 1, "cm")) +
  theme(panel.grid = element_blank())

p7
ggsave("../expression.pdf", p7)
ggsave("../expression.png", p7)

#################################
### Do the following yourself ###
#################################

# A while back we saved a RDS file named
# unsorted_lfc.rds.

# Use readRDS() to read this file into an object named
# ulfc. Determine its class and head() it.

# Use ggplot() to plot the logFC column on the y-axis
# against serial numbers on the x-axis.

# Convert logFC to linear fold change and plot as above.




