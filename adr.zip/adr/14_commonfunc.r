#############################
### Some Common Functions ###
#############################

# c(): concatenate.

rm(list = ls());

x <- c(2.17, 3.14, 13, 29, 48.356);
y <- c(200,300);
z <- c(x, y);
z;

# length(): Return the length of the named object.
length(x);
length(y);

# min() and max(): Minimum / Maximum element of an object.
min(x);
min(y);

# mean() and median():
mean(x);
median(y);

# summary(): Some key statistics about an object.
summary(y);


#####################
### Rounding etc. ###
#####################

# round()
pi
round(pi)
round(pi, 3);

# signif()
signif(pi)
signif(pi, 6);
signif(pi, 3);

# floor()
floor(pi)

# ceiling()
ceiling(pi)

############################
### paste() and paste0() ###
############################

# Always return a character vector.

rm(list = ls());

x <- LETTERS[1:10]
y <- seq(1,10);

paste(x);
paste(y);   # A character vector.
typeof(paste(y));

paste(x, y);
paste0(x, y);  # No separator.

y <- seq(1,5);
paste0(x, y);  # y is shorter than x, hence recycling.

z <- c(".k1", ".k2");
paste0(x, y, z); # z is also recycled as needed.


# You can "collapse" the resulting vector to a single
# string.

paste0(x, y, collapse = " ");

#################################
### Do the following yourself ###
#################################

mtl <- LETTERS[1:8]
mtn <- seq(1,12)

# Using rep() and paste0() and the two vectors made
# above, make a vector of all the addresses on a 96
# well microtitre plate.

# A1 to A12 then B1 to B12 ... H1 to H12.

# Hint: call to rep() will go inside the call to paste0()
# and will also use the named argument "each".




