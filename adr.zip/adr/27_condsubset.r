##############################
### Conditional subsetting ###
##############################

rm(list = ls());

data <- readRDS("data.rds");

head(data);
nrow(data)


up1.tf <- data$logFC >= 1;
up1 <- data[up1.tf, ];
nrow(up1);
head(up1)

up1c7.tf <- data$logFC >= 1 & data$control >= 7 ;
up1c7 <- data[up1c7.tf, ];
nrow(up1c7)
head(up1c7)

############################
### which() and subset() ###
############################

which17 <- which(data$logFC >= 1 & data$control >= 7);
class(which17)
which17
up1c7 <- data[which17, ];
nrow(up1c7)
head(up1c7)

################
### subset() ###
################

fc1c7 <- subset(data, logFC >= 1 & control >= 7);
fc1c7;
fc1c7 <- subset(data, data$logFC >= 1 & data$control >= 7);
fc1c7;


#################################
### Do the following yourself ###
#################################

# 1. Make a new data frame containing just the control and
#    treatment columns from data.

# 2. Use rowMeans() on this new data frame to get the average of
#    control and treatment for each row.

# 3. Add a column named "avexp" to data containing the vector
#    obtained in the step above.

# 4. Select rows from data where avexp is more than or equal to 6
#    and abs(logFC) is more than or equal to 4.

# 5. How many rows do you get in the step above?

####################################
### Vectorised or non-vectorised ###
####################################

set.seed(3141593); # So that we have the same random numbers.
x <- runif(10, min = 3, max = 6);
y <- runif(10, min = 12, max = 20);
df <- data.frame(x = x, y = y);
df
subset(df, x > 4 & y > 15);
subset(df, x > 4 && y > 15);

subset(df, x < 4 | y < 15);
subset(df, x < 4 || y < 15);

# What is the output of 
# 1. df$x > 4 & df$y > 15
# 2. df$x > 4 && df$y > 15
# 3. df$x < 4 | df$y < 15
# 4. df$x < 4 || df$y < 15

###################
### dplyr style ###
###################

### group_by() and summarise() ###

tib <- readRDS("tib.rds");
stib <- arrange(tib, desc(abs(logFC)));

group_by(stib, lfc3 = abs(logFC) >= 3) %>%
summarise(count = n());

stib %>% group_by(lfc3 = abs(logFC) >= 3) %>%
          summarise(count = n());

# Take care not to put the pipe at the start of a line.

### filter() ###

# Note dplyr::filter() masks functions of the same
# name in base and stats packages.

# At least two-fold upregulated.

stib %>% filter(logFC >= 1)
filter(stib, logFC >= 1)

stib %>% filter(logFC >= 1) %>% summarise(count = n())

# Reminder to demonstrate the consequence of putting
# the pipe at the start of a line.

stib %>% filter(logFC >= 1 & control >= 7) %>%
  summarise(count = n())

stib %>% filter(logFC >= 1 & control >= 7
   & (grepl("regulator|sigma|transcription", product,
      ignore.case = T))
    ); 

# Below is the same as above.
filter(stib, logFC >= 1 & control >= 7
   & (grepl("regulator|sigma|transcription", product,
      ignore.case = T))
    ); 

# The outputs of the above two are assignable.

hiup2 <- filter(stib, logFC >= 1 & control >= 7
   & (grepl("regulator|sigma|transcription", product,
      ignore.case = T))
    ); 
hiup2


