# RStudio

* Start RStudio.

## Getting the scripts and data we will be using

In Rstudio, use the drop down menu to do

    File -> New File -> R Script

In the blank R script we will write and run
the indented lines shown below. Please do this
with me so I can explain each step.

    setwd("u:/")
    unlink("Rtrain", recursive = TRUE)
    dir.create("Rtrain")
    
    setwd("Rtrain")
    
    getwd()
    
    unlink("*")
    
    list.files()
    
    download.file("https://github.com/streptomyces/advancedR/raw/jan2023/adr.zip", "adr.zip")
    # download.file("https://streptomyces.s3.eu-west-1.amazonaws.com/adr.zip", "adr.zip");
    
    list.files()
    
    unzip("adr.zip")
    
    setwd("adr")
    
    list.files()

### Four panes

* Source editor
* Console
* Environment and History
* File, Plots, Help etc.

### Getting started

* Type commands in the _source_ editor.

* To run a command from the _source_ editor place the
  cursor anywhere on that line and press `Control-Enter`.

* You can also select multiple lines and then press
  `Control-Enter` to run all the selected lines.

* Finally, you can use `Control-Shift-Enter` to _source_
  (i.e. run) the entire script.

* The action happens in the _Console_ pane. i.e. any
  output from R is shown in the console frame. You can
  also type commands directly in the console.

* R keeps a history of your commands which you can see in
  the history tab of RStudio.

* You can select and run commands from the history tab as
  well. Just press enter on the current line or select some
  lines and press enter.

* However you run a command, it is like typing it into
  the console and pressing Enter.

* Matching parentheses and quotes are automatically
  inserted. You can disable this in options. I do.
  (`Tools -> Global Options -> Code -> Editing`)

#### My preferred arrangement of RStudio panes

Use the drop down menus to do the following.

    Tools -> Global Options -> Pane layout

Arrange to have *Source* on the top left and *Console*
on the top right. With this arrangement we can minimise
two bottom panes most of the time and have more of
screen space.

