###########################
### Sorting a data frame ###
############################

# Three related functions: sort(), order(), rank()

### sort() ###

rm(list = ls());

set.seed(4); # So that we have the same random numbers.
x <- ceiling(runif(10, 30, 300))
x <- as.integer(x);
length(unique(x));
sx <- sort(x)
sx

### The order of numbers in x itself is unchanged by the sort
### operation. sx is a new vector.

### rank() ###

rx <- rank(x)

rx

### order() ###

ox <- order(x);

ox;

# For the same vector x, compare the output of rank() and order()
# x, ox and rx.


# To sort a data frame by some column, we cannot simply use
# sort().

# 1. First we get the order of rows by calling order() on the
#    column we wish to sort by.

# 2. Then we use the order to sort the entire data frame.

data <- readRDS("data.rds");

ordvec <- order(data$logFC);
sdata <- data[ordvec, ];
head(sdata);
tail(sdata);

#################################
### Do the following yourself ###
#################################

data <- readRDS("data.rds");

# 1. It would be more meaningful to sort data on absolute log
#    fold change and to have the highest change at the top.

# 2. The function for getting absolute values is abs().

# 3. Consult the help for order() to find the named argument you
#    need to use to order in decreasing order.

# 4. Now sort data by decreasing value of absolute logFC.


### Breaking ties ###

# If you have ties in the column you are sorting by then you
# might wish to use a second column to break the ties.
 
# Below, I am copying data to data2 and setting some control
# values to 50.

data2 <- data;
data2[c("SCO0500", "SCO0501", "SCO0502", "SCO0503") , "control"] <- 50;

# Suppose we wish to sort this data frame in decreasing order by
# the control value but in increasing order by the absolute
# logFC.

ordvec <- order(-data2$control, abs(data2$logFC))
sdata2 <- data2[ordvec, ]
head(sdata2)

###################
### dplyr style ###
###################

tib <- readRDS("tib.rds");

stib <- arrange(tib, logFC);
stib

stib <- arrange(tib, desc(abs(logFC)));
stib



