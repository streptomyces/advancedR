########################
### Basic data types ###
########################

# Character (strings of characters)
# Numbers
  ## Integers
  ## Real (double precision floating point numbers)
# Logical. TRUE or FALSE only.
# Complex
# Raw

# We will not bother with the Complex and Raw types.

# Mostly we don't have to worry whether our numeric
# variables are integers or doubles. There are functions to
# coerce one into another if needed.

# Explain x <- 42L

x <- 42;

y <- 42L;

typeof(x);

typeof(y);


